package estudoCrud.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudoCrudApplication.class, args);
	}

}
